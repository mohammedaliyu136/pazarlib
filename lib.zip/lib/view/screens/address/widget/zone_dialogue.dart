import 'package:efood_multivendor/controller/location_controller.dart';
import 'package:efood_multivendor/controller/order_controller.dart';
import 'package:efood_multivendor/controller/restaurant_controller.dart';
import 'package:efood_multivendor/data/model/response/address_model.dart';
import 'package:efood_multivendor/util/dimensions.dart';
import 'package:efood_multivendor/view/screens/address/widget/address_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class ZoneDialogue extends StatelessWidget {
  final TextEditingController zoneController;
  final TextEditingController zoneNameController;

  const ZoneDialogue({Key key, @required this.zoneController, @required this.zoneNameController}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<LocationController>(builder: (locationController) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Dimensions.RADIUS_SMALL)),
          insetPadding: EdgeInsets.all(30),
          clipBehavior: Clip.antiAliasWithSaveLayer,
          child: SizedBox(
            width: 500,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: Dimensions.PADDING_SIZE_SMALL, horizontal: Dimensions.PADDING_SIZE_EXTRA_SMALL),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(),
                      Text('Select Zone'),
                      InkWell(onTap: () => Get.back(), child: Icon(Icons.clear)),
                    ],
                  ),
                ),

                Expanded(
                  child: ListView.builder(
                      itemCount: locationController.allZoneList.length,
                      itemBuilder: (context, index){
                        return GestureDetector(
                          onTap: (){
                            //locationController.setZone(locationController.allZoneList[index].id);
                            zoneController.text=locationController.allZoneList[index].id.toString();
                            zoneNameController.text=locationController.allZoneList[index].name;
                            Get.back();
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(locationController.allZoneList[index].name),
                                SizedBox(height: 10,),
                                SizedBox(height: 0.2,child: Container(color: Colors.black,),),
                              ],
                            ),
                          ),
                        );
                      }),
                ),
              ],
            ),
          ),
        );
      }
    );
  }
}
