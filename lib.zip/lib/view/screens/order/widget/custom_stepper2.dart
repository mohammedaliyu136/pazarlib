import 'package:efood_multivendor/util/dimensions.dart';
import 'package:efood_multivendor/util/styles.dart';
import 'package:flutter/material.dart';

class CustomStepper2 extends StatelessWidget {
  final bool isActive;
  final bool haveUpperBar;
  final bool haveBottomBar;
  final String title;
  final bool rightActive;
  CustomStepper2({@required this.title, @required this.isActive, @required this.haveUpperBar, @required this.haveBottomBar,
    @required this.rightActive});

  @override
  Widget build(BuildContext context) {
    Color _color = isActive ? Theme.of(context).primaryColor : Theme.of(context).disabledColor;
    Color _right = rightActive ? Theme.of(context).primaryColor : Theme.of(context).disabledColor;

    return Expanded(
      child: Row(children: [

        Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
          //Expanded(child: haveUpperBar ? Divider(color: _color, thickness: 2) : SizedBox()),
          if(haveUpperBar)Padding(
            padding: const EdgeInsets.only(left:8.0),
            child: SizedBox(height: 50, width: 2, child: Container(color: Colors.black,),),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(vertical: isActive ? 0 : 5),
                child: Icon(isActive ? Icons.check_circle : Icons.blur_circular, color: _color, size: isActive ? 25 : 15),
              ),
              Text(
                title+'\n', maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                style: robotoMedium.copyWith(color: _color, fontSize: Dimensions.fontSizeExtraSmall),
              ),
            ],
          ),
          if(haveBottomBar)Padding(
            padding: const EdgeInsets.only(left:10.0),
            child: SizedBox(height: 50, width: 2, child: Container(color: Colors.black,),),
          ),
          //Expanded(child: haveBottomBar ? Divider(color: _right, thickness: 2) : SizedBox()),
        ]),

      ]),
    );
  }
}
