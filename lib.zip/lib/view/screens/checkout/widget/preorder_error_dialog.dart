import 'package:efood_multivendor/controller/order_controller.dart';
import 'package:efood_multivendor/controller/splash_controller.dart';
import 'package:efood_multivendor/helper/price_converter.dart';
import 'package:efood_multivendor/helper/route_helper.dart';
import 'package:efood_multivendor/util/dimensions.dart';
import 'package:efood_multivendor/util/images.dart';
import 'package:efood_multivendor/util/styles.dart';
import 'package:efood_multivendor/view/base/custom_button.dart';
import 'package:efood_multivendor/view/base/custom_snackbar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PreOrderErrorDialog extends StatelessWidget {
  final String products;
  PreOrderErrorDialog({@required this.products});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Dimensions.RADIUS_SMALL)),
      insetPadding: EdgeInsets.all(30),
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: SizedBox(
          width: 500,
          child: Padding(
            padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: EdgeInsets.all(Dimensions.PADDING_SIZE_LARGE),
                child: Text(
                  'You can\'t order a preorder item for instant delivery or pickup\n\nPreorder Items in your cart:\n$products',
                  style: robotoMedium.copyWith(
                      fontSize: Dimensions.fontSizeDefault),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(height: Dimensions.PADDING_SIZE_LARGE),
              TextButton(
                onPressed: () {
                  Get.back();
                },
                style: TextButton.styleFrom(
                  backgroundColor:
                      Theme.of(context).disabledColor.withOpacity(0.3),
                  minimumSize: Size(Dimensions.WEB_MAX_WIDTH, 40),
                  padding: EdgeInsets.zero,
                  shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(Dimensions.RADIUS_SMALL)),
                ),
                child: Text('Close',
                    textAlign: TextAlign.center,
                    style: robotoBold.copyWith(
                        color: Theme.of(context).textTheme.bodyLarge.color)),
              ),
            ]),
          )),
    );
  }
}
