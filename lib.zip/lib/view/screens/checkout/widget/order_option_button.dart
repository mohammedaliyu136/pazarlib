import 'package:efood_multivendor/controller/order_controller.dart';
import 'package:efood_multivendor/controller/restaurant_controller.dart';
import 'package:efood_multivendor/util/dimensions.dart';
import 'package:efood_multivendor/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OrderOptionButton extends StatelessWidget {
  final String value;
  final String title;
  final int index;
  OrderOptionButton({@required this.value, @required this.title, @required this.index});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RestaurantController>(builder: (restController) {
          //bool _select = restController. //restController.restaurant.preOrder;
          print("klkklkkkkklkkllk");
          print(restController.restaurant.orderType);
          bool _select = false;//restController. //restController.restaurant.preOrder;

          if(restController.restaurant.orderType=="instant_order" && index==1){
            _select = true;
          }
          if(restController.restaurant.orderType=="pre_order" && index==0){
            _select = true;
          }
          print("${_select}-----000====${restController.restaurant.orderType}-----000====${index}");
            return InkWell(
              onTap: () {
                /*
                if(index==0 && restController.restaurant.orderType=="pre_order"){
                  _select=true;
                }if(index==1 && restController.restaurant.orderType=="instant_order"){
                  _select=true;
                }
                if(index!=0){
                  restController.restaurant.instantOrder=true;
                  restController.restaurant.preOrder=false;
                  restController.restaurant.orderType="instant_order";
                }else{
                  restController.restaurant.instantOrder=false;
                  restController.restaurant.preOrder=true;
                  restController.restaurant.orderType="pre_order";
                }*/
                /*
                if(restController.restaurant.orderType=="instant_order"){
                  restController.restaurant.orderType="pre_order";
                }else{
                  restController.restaurant.orderType="instant_order";
                }*/
                if(index==0){
                  _select = true;
                  restController.updateDeliveryOption(restController.restaurant,"pre_order");
                  //restController.restaurant.orderType="pre_order";
                }
                if(index==1){
                  _select = true;
                  //restController.restaurant.orderType="instant_order";
                  restController.updateDeliveryOption(restController.restaurant,"instant_order");
                }
                print(index.toString()+" -- -- - - -- 00909");
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_DEFAULT, vertical: Dimensions.PADDING_SIZE_SMALL),
                decoration: BoxDecoration(
                  color: _select ? Theme.of(context).primaryColor.withOpacity(0.05) : Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(Dimensions.RADIUS_LARGE)
                ),
                child: Row(
                  children: [
                    // Radio(
                    //   value: value,
                    //   groupValue: restController.orderType,
                    //   materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    //   onChanged: (String value) => restController.setOrderType(value),
                    //   activeColor: Theme.of(context).primaryColor,
                    // ),
                    SizedBox(width: 5),

                    Text(title, style: robotoRegular.copyWith(color: _select ? Theme.of(context).primaryColor : Theme.of(context).disabledColor)),
                    SizedBox(width: 5),

                    // Text(
                    //   '(${(value == 'take_away' || isFree) ? 'free'.tr : charge != -1 ? PriceConverter.convertPrice(charge) : 'calculating'.tr})',
                    //   style: robotoMedium,
                    // ),

                  ],
                ),
              ),
            );
          },
        );
  }
}
