import 'package:efood_multivendor/controller/location_controller.dart';
import 'package:efood_multivendor/data/model/response/address_model.dart';
import 'package:efood_multivendor/util/dimensions.dart';
import 'package:efood_multivendor/view/base/custom_loader.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:efood_multivendor/data/model/response/zone_response_model.dart';

class SetLocation extends StatefulWidget {
  bool fromNav;
  SetLocation({Key key, this.fromNav=false}) : super(key: key);

  @override
  State<SetLocation> createState() => _SetLocationState();
}

class _SetLocationState extends State<SetLocation> {
  bool loadingZones = true;
  bool loadingPage = true;
  bool firstRun = true;
  @override
  void initState() {
    //Get.find<LocationController>().getZones().then((value){
      //loadingZones=false;
    //});
    Get.find<LocationController>().getStates(initRun: true).then((value) => loadingPage=false);
    //Get.find<LocationController>().getStates();
    //runLocation();
    loadingPage=false;
    super.initState();
  }

  // Initial Selected Value
  //StateModel selectedState;// = StateModel(id: 1, name: "Abuja");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //appBar: AppBar(),
      //backgroundColor: Colors.red,
      body: SafeArea(
        child: GetBuilder<LocationController>(builder: (locationController) {
                if(locationController.stateLoading){
                  return Center(child: CircularProgressIndicator());
                }
                return Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      constraints: BoxConstraints(minWidth: 10, maxWidth: MediaQuery.of(context).size.width>Dimensions.WEB_MAX_WIDTH?Dimensions.WEB_MAX_WIDTH:MediaQuery.of(context).size.width),
                      child: Scaffold(
                        //backgroundColor: Colors.red,
                        body: Stack(
                          children: [
                            //Container(width: MediaQuery.of(context).size.width, height: MediaQuery.of(context).size.height,color: Colors.white,),
                            //Container(width: MediaQuery.of(context).size.width, height: MediaQuery.of(context).size.height,color: Colors.red.withOpacity(0.15),),
                            Column(
                              //mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                /*
                                Container(
                                  height: MediaQuery.of(context).size.height/10,
                                  color: Colors.red, width: MediaQuery.of(context).size.width, child: Icon(Icons.delivery_dining, color: Colors.transparent, size: 50,),),
                                */
                                if(!loadingPage)Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        //color: Colors.red.withOpacity(0.15),
                                        //borderRadius: BorderRadius.only(topRight: Radius.circular(12), topLeft: Radius.circular(12)),
                                      ),
                                      //width: MediaQuery.of(context).size.height,
                                      height: 0,
                                    ),
                                    SizedBox(height: 10,),
                                    Row(
                                      children: [
                                        if(widget.fromNav)Container(
                                            height: 50, width: 50),
                                        if(!widget.fromNav)IconButton(
                                          icon: Container(
                                            height: 50, width: 50,
                                            decoration: BoxDecoration(shape: BoxShape.circle, color: Theme.of(context).primaryColor),
                                            alignment: Alignment.center,
                                            child: Icon(Icons.chevron_left, color: Theme.of(context).cardColor),
                                          ),
                                          onPressed: () => Get.back(),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(left: 8.0),
                                          child: Row(
                                            children: [
                                              Text('Select your ', style: TextStyle(fontWeight: FontWeight.w400, fontSize: 18),),
                                              Text('Location', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 5,),
                                    SizedBox(
                                      height: 54,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: ListView.builder(
                                                itemCount: locationController.stateList.length,
                                                scrollDirection: Axis.horizontal,
                                                itemBuilder: (BuildContext context,int index){
                                                  return GestureDetector(
                                                    onTap: (){
                                                      locationController.saveSelectedState(locationController.stateList[index]);
                                                      locationController.getZones(stateID: locationController.stateList[index].id, index: index);

                                                      //locationController.getZones(stateID: 1, index: 1);
                                                    },
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(8.0),
                                                      child: locationController.selectedState!=null?Container(
                                                        decoration: BoxDecoration(
                                                          color: locationController.selectedState.id==locationController.stateList[index].id?Colors.red:Colors.grey.shade200,
                                                          borderRadius: BorderRadius.circular(12),
                                                        ),
                                                        child: Padding(
                                                          padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 15),
                                                          child: Text(
                                                            locationController.stateList[index].name,
                                                            style: locationController.selectedState.id==locationController.stateList[index].id?TextStyle(color: Colors.white):TextStyle(color: Colors.black),),
                                                        ),):Container(
                                                        decoration: BoxDecoration(
                                                          color: locationController.selectedState.id==locationController.stateList[index].id?Colors.red:Colors.grey.shade200,
                                                          borderRadius: BorderRadius.circular(12),
                                                        ),
                                                        child: Padding(
                                                          padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 15),
                                                          child: Text(
                                                            locationController.stateList[index].name,
                                                            style: locationController.selectedState.id==locationController.stateList[index].id?TextStyle(color: Colors.white):TextStyle(color: Colors.black),),
                                                        ),),
                                                    ),
                                                  );
                                                }
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 10,),
                                    SizedBox(height: 1.5,child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 12.0),
                                      child: Container(color: Colors.black.withOpacity(0.15),),
                                    ),),
                                    SizedBox(height: 20,),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 8.0),
                                      child: Row(
                                        children: [
                                          Text('Select your ', style: TextStyle(fontWeight: FontWeight.w400, fontSize: 18),),
                                          Text('Zone', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 5,),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 8.0),
                                      child: Row(
                                        children: [
                                          Text('You can only select one zone ', style: TextStyle(fontWeight: FontWeight.w400, color: Colors.grey.shade500),),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 10,),
                                    if(locationController.zoneListLoading)Center(child: CircularProgressIndicator()),

                                    if(!locationController.zoneListLoading)SizedBox(
                                      height: ((MediaQuery.of(context).size.height/3)*2)-40,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: ListView.builder(
                                                itemCount: locationController.allZoneList.length,
                                                itemBuilder: (BuildContext context,int index){
                                                  return GestureDetector(
                                                    onTap: (){
                                                      print("here here.....");

                                                      Get.dialog(CustomLoader(), barrierDismissible: false);
                                                      AddressModel _addressModel = AddressModel(
                                                        latitude: '12.1233', longitude: '10.2212',
                                                        stateId: locationController.selectedState.id,
                                                        addressType: locationController.allZoneList[index].name,
                                                        zoneId: locationController.allZoneList[index].id,
                                                        address: locationController.allZoneList[index].name,
                                                      );

                                                      /*
                                                      _addressModel.zoneData = [];
                                                      _addressModel.zoneData = [
                                                        ZoneData(
                                                            id: locationController.allZoneList[index].id,
                                                            status: locationController.allZoneList[index].status,
                                                            minimumShippingCharge:locationController.allZoneList[index].minimumShippingCharge,
                                                            perKmShippingCharge:locationController.allZoneList[index].perKmShippingCharge,
                                                            maxCodOrderAmount:locationController.allZoneList[index].maxCodOrderAmount,
                                                            maximumShippingCharge:locationController.allZoneList[index].maximumShippingCharge
                                                        )];
                                                      */
                                                      print(_addressModel.toJson());
                                                      //locationController.saveState(selectedState);
                                                      locationController.saveAddressAndNavigate(_addressModel, false, Get.currentRoute, false);
                                                    },
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(8.0),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Colors.grey.shade200,
                                                          borderRadius: BorderRadius.circular(12),
                                                        ),
                                                        child: Padding(
                                                          padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16),
                                                          child: Text(locationController.allZoneList[index].name, style: TextStyle(color: Colors.black, fontSize: 17, fontWeight: FontWeight.w500),),
                                                        ),),
                                                    ),
                                                  );
                                                }
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    /*
                                  TextButton(
                                      onPressed: (){
                                        //locationController.getStates();
                                      },
                                      child: Text('run')),
                                  */
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
        }
        ),
      ),
    );
  }
}
