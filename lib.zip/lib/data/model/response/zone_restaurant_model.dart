import 'package:google_maps_flutter/google_maps_flutter.dart';

class RestaurantZoneModel {
  int id;
  String name;
  int zoneID;
  int restaurantID;
  int deliveryFee;
  String createdAt;
  String updatedAt;

  RestaurantZoneModel({this.id, this.name,this.createdAt, this.updatedAt, this.zoneID, this.restaurantID});

  RestaurantZoneModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    zoneID = json['zone_id'];
    restaurantID = json['restaurant_id'];
    deliveryFee = json['delivery_fee'];
    //status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['zone_id'] = this.zoneID;
    data['restaurant_id'] = this.restaurantID;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}