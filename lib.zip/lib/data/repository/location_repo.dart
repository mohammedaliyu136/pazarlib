import 'package:efood_multivendor/data/api/api_client.dart';
import 'package:efood_multivendor/data/model/response/address_model.dart';
import 'package:efood_multivendor/util/app_constants.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/response/response.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocationRepo {
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  LocationRepo({this.apiClient, this.sharedPreferences});

  Future<Response> getAllAddress() async {
    return await apiClient.getData(AppConstants.ADDRESS_LIST_URI);
  }

  Future<Response> getZone(String lat, String lng) async {
    return await apiClient.getData('${AppConstants.ZONE_URI}?lat=$lat&lng=$lng');
  }
  Future<Response> getZoneByID(int id) async {
    return await apiClient.getData(AppConstants.ZONE_BY_ID_URI+"?id=${id}");
  }
  Future<Response> getStates() async {
    return await apiClient.getData(AppConstants.STATE_LIST_URI);
  }

  Future<Response> removeAddressByID(int id) async {
    return await apiClient.postData('${AppConstants.REMOVE_ADDRESS_URI}$id', {"_method": "delete"});
  }

  Future<Response> addAddress(AddressModel addressModel) async {
    return await apiClient.postData(AppConstants.ADD_ADDRESS_URI, addressModel.toJson());
  }

  Future<Response> updateAddress(AddressModel addressModel, int addressId) async {
    return await apiClient.putData('${AppConstants.UPDATE_ADDRESS_URI}$addressId', addressModel.toJson());
  }

  Future<bool> saveSelectedState(StatesModel state) async {
    print("00000000000");
    print(state.id);
    return await sharedPreferences.setInt("state_id", state.id);
  }

  Future<int> getSelectedState() async {
    return await sharedPreferences.getInt("state_id")??0;
  }
  int isStateSelected(){
    return sharedPreferences.getInt("state_id")??-1;
  }

  Future<bool> saveUserAddress(String address, List<int> zoneIDs, String latitude, String longitude) async {
    apiClient.updateHeader(
      sharedPreferences.getString(AppConstants.TOKEN), zoneIDs,
      sharedPreferences.getString(AppConstants.LANGUAGE_CODE), latitude, longitude
    );
    return await sharedPreferences.setString(AppConstants.USER_ADDRESS, address);
  }

  Future<Response> getAddressFromGeocode(LatLng latLng) async {
    return await apiClient.getData('${AppConstants.GEOCODE_URI}?lat=${latLng.latitude}&lng=${latLng.longitude}');
  }

  String getUserAddress() {
    return sharedPreferences.getString(AppConstants.USER_ADDRESS);
  }

  Future<Response> searchLocation(String text) async {
    return await apiClient.getData('${AppConstants.SEARCH_LOCATION_URI}?search_text=$text');
  }

  Future<Response> getPlaceDetails(String placeID) async {
    return await apiClient.getData('${AppConstants.PLACE_DETAILS_URI}?placeid=$placeID');
  }
  Future<Response> getAllZones({int stateID, int restaurantID}) async {
    if(restaurantID==-1){
      return await apiClient.getData(AppConstants.ZONE_LIST_URI+"?state_id=${stateID}");
    }else{
      return await apiClient.getData(AppConstants.ZONE_LIST_URI+"?state_id=${stateID}&restaurant_id=${restaurantID}");
    }
  }

}
